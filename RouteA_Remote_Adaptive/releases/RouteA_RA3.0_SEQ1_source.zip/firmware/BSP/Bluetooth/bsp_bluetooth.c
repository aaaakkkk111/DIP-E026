#include "bsp_bluetooth.h"

#define UART5_TX_SIZE 512
static volatile uint16_t tx_head = 0;
static volatile uint16_t tx_tail = 0;
static uint8_t tx_ring[UART5_TX_SIZE];

/* Test_Mode only: buffer raw RX bytes; the main loop owns frame assembly. */
#define UART5_RX_SIZE 256
static volatile u16 rx_head = 0, rx_tail = 0;
static volatile u8 rx_fault = 0;
static u8 rx_ring[UART5_RX_SIZE];
static void UART5_RxPush(u8 value)
{
    u16 next;
    if(rx_fault) return;
    next = (u16)((rx_head + 1) & (UART5_RX_SIZE - 1));
    if(next == rx_tail) { rx_fault = 1; return; }
    rx_ring[rx_head] = value;
    rx_head = next;
}
int UART5_RxRead(u8 *value)
{
    u32 mask = __get_PRIMASK();
    int ready = 0;
    __disable_irq();
    if(rx_fault)
    {
        /* Discard the damaged stream and tell the assembler to resynchronize. */
        rx_tail = rx_head;
        rx_fault = 0;
        *value = 0;
        ready = 1;
    }
    else if(rx_tail != rx_head)
    {
        *value = rx_ring[rx_tail];
        rx_tail = (u16)((rx_tail + 1) & (UART5_RX_SIZE - 1));
        ready = 1;
    }
    __set_PRIMASK(mask);
    return ready;
}

int UART5_TxEnqueue(const char *s)
{
	uint16_t used, free_count, needed, next;
	needed = (uint16_t)strlen(s);
	used = (uint16_t)((tx_head + UART5_TX_SIZE - tx_tail) % UART5_TX_SIZE);
	free_count = (uint16_t)(UART5_TX_SIZE - used - 1);
	if(needed > free_count) return 0;
	while(*s)
	{
		next = (uint16_t)((tx_head + 1) % UART5_TX_SIZE);
		tx_ring[tx_head] = (uint8_t)*s++;
		tx_head = next;
	}
	USART_ITConfig(UART5, USART_IT_TXE, ENABLE);
	return 1;
}

//�������ڳ�ʼ�� ֻ����9600������
// Initialize the Bluetooth serial port, the baud rate can only be 9600
void bluetooth_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure; 
	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD , ENABLE);
	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);    

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	
	NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = (mode == Test_Mode) ? 1 : 3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	  
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No ;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(UART5, &USART_InitStructure); 
//	USART_ITConfig(UART5, USART_IT_TXE, DISABLE);  

	USART_ITConfig(UART5, USART_IT_RXNE, ENABLE);   
	USART_Cmd(UART5, ENABLE);
	
	
	Init_PID();
	
	
}


//����һ���ַ�  Send a character
void UART5_Send_U8(uint8_t ch)
{
	while (USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET)
		;
	USART_SendData(UART5, ch);
}

//����һ���ַ���  Send a string
/**
 * @Brief: UART5�������� UART5 sends data
 * @Note: 
 * @Parm: BufferPtr:�����͵�����(Data to be sent)  Length:���ݳ���(Data length)
 * @Retval: 
 */
void UART5_Send_ArrayU8(uint8_t *BufferPtr, uint16_t Length)
{
	while (Length--)
	{
		UART5_Send_U8(*BufferPtr);
		BufferPtr++;
	}
}

/*����5���ͺ��� Serial port 5 sending function*/
void USART5_Send_Byte(unsigned char byte)   //���ڷ���һ���ֽ� The serial port sends a byte
{
//	while( USART_GetFlagStatus(UART5,USART_FLAG_TC)!= SET);  
	while (USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET);
	USART_SendData(UART5, byte);        //ͨ���⺯��  ��������  Send data through library functions
        
}
void UART5_Send_Char(char *s)
{
	(void)UART5_TxEnqueue(s);
}

//�����жϷ�����  Serial port interrupt service function
void UART5_IRQHandler(void)
{
    u8 value;
    u32 status;
    if(mode == Test_Mode)
    {
        status = UART5->SR;
        if(status & (USART_SR_RXNE | USART_SR_ORE | USART_SR_FE | USART_SR_NE | USART_SR_PE))
        {
            /* SR then DR clears hardware receive errors; never execute a damaged frame. */
            value = (u8)UART5->DR;
            if(status & (USART_SR_ORE | USART_SR_FE | USART_SR_NE | USART_SR_PE)) rx_fault = 1;
            else if(status & USART_SR_RXNE) UART5_RxPush(value);
        }
    }
    else if(USART_GetITStatus(UART5, USART_IT_RXNE) != RESET)
    {
        value = (u8)USART_ReceiveData(UART5);
        deal_bluetooth(value);
    }
    if(USART_GetITStatus(UART5, USART_IT_TXE) != RESET)
    {
        if(tx_tail != tx_head)
        {
            USART_SendData(UART5, tx_ring[tx_tail]);
            tx_tail = (u16)((tx_tail + 1) % UART5_TX_SIZE);
        }
        else USART_ITConfig(UART5, USART_IT_TXE, DISABLE);
    }
}
